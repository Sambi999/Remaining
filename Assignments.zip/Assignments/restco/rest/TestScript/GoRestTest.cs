﻿using Newtonsoft.Json;
using rest.Utilities;
using RestSharp;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace rest.TestScript
{
    public class GoRestTest: CoreCodes
    {
        [Test]
        [Order(1)]
        public void GetUserDetails()
        {
            test = extent.CreateTest("Get All User");
            Log.Information("Get all user test");
            //string bearerToken = "f90fb78ba4cb4bca31dc3389c9652fe6b2384773cad4bb134aaf8f40428c73cb";
            var request = new RestRequest("", Method.Get);
            var response = client.Execute(request);

            try
            {
                Assert.That(response.StatusCode, Is.EqualTo(System.Net.HttpStatusCode.OK));
                Log.Information($"API Response: {response.Content}");

                List<UserData> users = JsonConvert.DeserializeObject<List<UserData>>(response.Content);

                Assert.NotNull(users);
                Log.Information("Get All User test passed");

                test.Pass("Get All User test passed");
            }
            catch (AssertionException)
            {
                test.Fail("Get All User test failed");
            }

        }
        [Test]
        [Order(2)]
        public void CreateUserTest()
        {
            test = extent.CreateTest("Create User");
            Log.Information("Create User Test Started");

            string bearerToken = "f90fb78ba4cb4bca31dc3389c9652fe6b2384773cad4bb134aaf8f40428c73cb";
            var request = new RestRequest("", Method.Post);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddJsonBody(new
            {
                name = "Anj",
                email = "anj_acri@wit.test",
                gender = "male",
                status = "inactive"
            });
            var response = client.Execute(request);

            try
            {
                Assert.That(response.StatusCode, Is.EqualTo(System.Net.HttpStatusCode.Created));
                Log.Information($"API Response: {response.Content}");

                var user = JsonConvert.DeserializeObject<UserData>(response.Content);
                Assert.NotNull(user);
                Log.Information("User created and returned");
                Assert.That(user.Name, Is.EqualTo("Anj"));
                Log.Information($"User Name matches with fetch {user.Name}");
               // Assert.That(user.Email, Is.EqualTo("anal_achari@lueilwit.test"));
                //Log.Information($"User Email matches with fetch {user.Email}");
                Assert.That(user.Gender, Is.EqualTo("male"));
                Log.Information($"User Gender matches with fetch {user.Gender}");
                Assert.That(user.Status, Is.EqualTo("inactive"));
                Log.Information($"User Status matches with fetch {user.Status}");

                Log.Information("Create User test passed");

                test.Pass("Create User Test passed");
            }
            catch (AssertionException)
            {
                test.Fail("Create User test failed");
            }
        }
        [Test]
        [Order(3)]
        public void UpdateUser()
        {
            test = extent.CreateTest("Update User Test");
            Log.Information("Update User Test");
            string bearerToken = "f90fb78ba4cb4bca31dc3389c9652fe6b2384773cad4bb134aaf8f40428c73cb";
            var request = new RestRequest("/5839000", Method.Put);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddJsonBody(new
            {
                name = "Allu",
                email = "allu@gmail.com",
                gender = "male",
                status = "active"
            });
            var response = client.Execute(request);
            try
            {
                Assert.That(response.StatusCode, Is.EqualTo(System.Net.HttpStatusCode.OK));
                Log.Information($"Api Response:{response.Content}");
                var details = JsonConvert.DeserializeObject<UserData>(response.Content);
                Assert.NotNull(details);
                Log.Information("User Details Updated");
                Assert.That(details.Name, Is.EqualTo("Allu"));
                Log.Information("Update User Test Passed");
                test.Pass("Update User Test Passed");


            }
            catch (AssertionException)
            {
                test.Fail("Update User Test Failed");
            }

        }
        [Test]
        [Order(4)]
        public void DeleteUser()
        {
            test = extent.CreateTest("Delete User Test");
            Log.Information("Delete User Test");
            string bearerToken = "f90fb78ba4cb4bca31dc3389c9652fe6b2384773cad4bb134aaf8f40428c73cb";
            var request = new RestRequest("5839002", Method.Delete);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", $"Bearer {bearerToken}");

            var response = client.Execute(request);
            try
            {
                Assert.That(response.StatusCode, Is.EqualTo(System.Net.HttpStatusCode.NoContent));
                Log.Information($"Api Error:{response.Content}");
                var data = JsonConvert.DeserializeObject<UserData>(response.Content);
                Assert.IsNull(data);
                Log.Information("Delet Test Passed");
                test.Pass("Delete User Test Passed");

            }
            catch (AssertionException)
            {
                test.Fail("Delete user Test");
            }
        }
    }
}
